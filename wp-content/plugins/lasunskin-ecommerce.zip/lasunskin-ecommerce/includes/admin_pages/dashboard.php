<?php
echo __FILE__;