<?php
?>
<div class="form-field">
    <label for="category_image">Hinh ảnh</label>
    <input type="text" name="category_image" id="category_image" size="40" >
</div>
